﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking_Automation.Config.Database_Query
{
    internal class DBQuery
    {
        public static string database_Query = "SELECT  [Testcase] FROM [Framework].[dbo].[TestData] where testdata='Laptop';";
        public static string CredentialforToken = "SELECT [Username],[Password] FROM [Framework].[dbo].[Credentials];";
        public static string DBAllDataResponse = "SELECT [Testcase],[Browser],[URL],[testdata] FROM [Framework].[dbo].[TestData]";
    }
}
