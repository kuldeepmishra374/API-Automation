﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using log4net;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks_RestAPI_Automation.Config
{
    /// <summary>
    /// App setting variables declaration
    /// </summary>
    public static class Settings
    {
        public static string? BaseURL { get; set; }

        // public static string AppSettingPath = new CommonUtils().SolutionPath().ToString() + "\\appsettings.json";
        // public static Dictionary<string, string> ConfigSettings { get; set; }
        // public static Dictionary<string, string> TData { get; set; }
        // public static char UserDelimeter { get; set; } = ':';
        // public static string TestDataPath { get; set; } = new CommonUtils().GetFolderPath("TestData") + "TestData.json";

        public static string? DBType { get; set; }
        public static string? WorkOrderCleanUp { get; set; }
        public static string? Environment { get; set; }
        public static bool ExtentReport { get; set; }
        public static string? OracleConnectionString { get; set; }
        public static string? SQLConnectionString { get; set; }
        public static DbConnection connection { get; set; }

        public static bool Logs { get; set; }

        public static ILog Logger { get; set; }

        public static string? userName { get; set; }
        public static string? passWord { get; set; }

        public static string? DatabaseName { get; set; }
        public static string? DBusername { get; set; }
        public static string? DBpassword { get; set; }
        public static string? Server { get; set; }
    }
}
