﻿using AssetWorks_RestAPI_Automation.Config;
using AssetWorks_RestAPI_Automation.Hook;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.Logs;
//using AssetWorks_RestAPI_Automation.Hook;

namespace AssetWorks_RestAPI_Automation.ConfigData
{
    /// <summary>
    /// Reading app setting configuration variables
    /// </summary>
    public class ConfigurationData
    {
        public static void SetConfigData()
        {

            Settings.Logs = bool.Parse(TestContext.Parameters["Logs"]);
            Settings.ExtentReport = bool.Parse(TestContext.Parameters["ExtentReport"]);
            if (Settings.Logger == null)
              //  Settings.Logger = Core.Logs.Logs.Log<Hooks>();
            Settings.Logger = Logs.Log<Hooks>();
            Settings.Logger.Info("------------Setting variables initialization------------");
            Settings.Logger.Info($"Settings.Logs: {Settings.Logs}");
            //  Settings.Logger.Info($"Settings.Logs: {AppSettings.Logs}");
            //Intializing username and password in class variable

            Settings.userName = TestContext.Parameters["username"];
            Settings.passWord = TestContext.Parameters["password"];

            //Intializing database username and password in class variable
            Settings.DBusername = TestContext.Parameters["DBusername"];
            Settings.DBpassword = TestContext.Parameters["DBpassword"];
            Settings.DatabaseName = TestContext.Parameters["Database"];
            Settings.Server = TestContext.Parameters["Server"];

            Settings.DBType = TestContext.Parameters["DBType"];
            Settings.WorkOrderCleanUp = TestContext.Parameters["WorkOrderCleanUp"];

            Settings.Environment = TestContext.Parameters["Environment"];

            if (Settings.Environment.Contains("QA"))
            {
                Settings.BaseURL = TestContext.Parameters["QA_BaseUrl"];
                //Settings.OracleConnectionString = TestContext.Parameters["QA_OracleConnectionString"];
                //Settings.SQLConnectionString = TestContext.Parameters["QA_SQLConnectionString"];
            }
            else if (Settings.Environment.Contains("Dev"))
            {
                Settings.BaseURL = TestContext.Parameters["Dev_BaseUrl"];
                //Settings.OracleConnectionString = TestContext.Parameters["UAT_OracleConnectionString"];
                //Settings.SQLConnectionString = TestContext.Parameters["UAT_SQLConnectionString"];
            }
            else
                Settings.BaseURL = TestContext.Parameters["Prod_BaseUrl"];

        }


    }
}
