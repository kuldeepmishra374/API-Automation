﻿using AssetWorks_API_Automation.Webservices.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking_Automation.Request
{
    public  class CreateBooking
    {
        public long Bookingid { get; set; }
        public List<Booking> data { get; set; }
    }

    public  class Booking
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public long Totalprice { get; set; }
        public bool Depositpaid { get; set; }
        public Bookingdates Bookingdates { get; set; }
        public string Additionalneeds { get; set; }
    }

    public  class Bookingdates
    {
        public DateTimeOffset Checkin { get; set; }
        public DateTimeOffset Checkout { get; set; }
    }
    public  class GetBooking
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public long Totalprice { get; set; }
        public bool Depositpaid { get; set; }
        public string Additionalneeds { get; set; }
        //public List<Bookingdates> data { get; set; }
    }

    public  class UpdateBooking
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public long Totalprice { get; set; }
        public bool Depositpaid { get; set; }
        public string Additionalneeds { get; set; }
    }

   

}
