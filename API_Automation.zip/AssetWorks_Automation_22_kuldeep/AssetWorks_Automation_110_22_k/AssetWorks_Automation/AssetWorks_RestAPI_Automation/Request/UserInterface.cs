﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks_API_Automation.Webservices.Request
{
    public class CreateUser
    {
        public string Name { get; set; }
        public string Job { get; set; }

    }

    public class PostRequest
    {
        public string Name { get; set; }
        public string Job { get; set; }
        public long Id { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
    }
    public class CreateRequest
    {
        public string Name { get; set; }
        public string Job { get; set; }
        public string Endpoint { get; set; }
    }

    //public class UserPageResponse
    //{
    //    public int page { get; set; }
    //    public int per_page { get; set; }
    //    public int total { get; set; }
    //    public int total_pages { get; set; }
    //    public List<Datam> data { get; set; }

    //}

    public class UserPageResponse
    {
        public Datam data { get; set; }
        public Support support { get; set; }
    }

    public class Datam
    {
        public int id { get; set; }
        public string email { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string avatar { get; set; }
    }

    public class Support
    {
        public string url { get; set; }
        public string text { get; set; }
    }
    public class UserPutRequest
    {
        public string Name { get; set; }
        public string Job { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
    }
}
