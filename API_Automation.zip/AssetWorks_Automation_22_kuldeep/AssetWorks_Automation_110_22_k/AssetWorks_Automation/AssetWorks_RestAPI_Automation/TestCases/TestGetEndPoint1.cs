﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Threading.Tasks;
using AssetWorks_API_Automation.Webservices.API_Functions;
using AssetWorks_API_Automation.Webservices.Request;
using AssetWorks_RestAPI_Automation.Config;
using AssetWorks_RestAPI_Automation.Hook;

namespace AssetWorks_API_Automation.RestGetEndPoint
{
    [TestFixture]
    
    public class TestGetEndPoint1 :Hooks

    {
        public dynamic genericObject;
        UsrerInterface objectUserinterface = new UsrerInterface();
        //  private static readonly ILog log = LogManager.GetLogger(typeof(TestGetEndPoint));


        [TestCase("UserData.json", "TC01_CreateUser")]
        public void TC016_CreateUser(object[] testParameter)
        {
            Settings.Logger.Info("LoadTestData function execution started.....");
            objectUserinterface.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            genericObject = objectUserinterface.CreateUser();
            objectUserinterface.VerifyPostRequest(genericObject);
        }

        [TestCase("UserData.json", "TC03_PutRequest")]
        public void TC07_PutRequest(object[] testParameter)
        {
            Settings.Logger.Info("LoadTestData function execution started.....");
            objectUserinterface.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            Settings.Logger.Info("Update function execution started.....");
            genericObject = objectUserinterface.UpdateUser();
            Settings.Logger.Info("Verification started....");
            objectUserinterface.VerifyPutRequest(genericObject, testParameter[0].ToString(), testParameter[1].ToString());
        }

        [TestCase("UserData.json", "TC02_GetUser")]
        //  [TestCase("UserData.json", "TC03_VerifyGetInvalidUser")]
        public void TC08_GetUser(object[] testParameter)
        {
            Settings.Logger.Info("LoadTestData function execution started.....");
            objectUserinterface.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            Settings.Logger.Info("GetUser function execution started.....");
            UserPageResponse genericObject = objectUserinterface.GetUser();
            Settings.Logger.Info("Verification started....");
            objectUserinterface.VerifyGetRequest(genericObject);
            Settings.Logger.Info("GetUser function execution finished....");

        }

        [TestCase("UserData.json", "TC03_VerifyGetInvalidUser")]
        public void TC09_VerifyWithGetInvalidUser(object[] testParameter)
        {
            Settings.Logger.Info("LoadTestData function execution started.....");
            objectUserinterface.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            UserPageResponse genericObject = objectUserinterface.GetUser();
            Settings.Logger.Info(" InvalidUser Request Verification started....");
            objectUserinterface.VerifyWithGetInvalidUserRequest(genericObject);
        }

        [TestCase("UserData.json", "TC04_DeleteRequest")]
        public void TC10_DeleteRequest(object[] testParameter)
        {
            Settings.Logger.Info("DeleteUser function execution started.....");
            genericObject = objectUserinterface.DeleteUser();
            Settings.Logger.Info("Verification started....");
            objectUserinterface.VerifyDeleteRequest(genericObject);
        }


    }
}
