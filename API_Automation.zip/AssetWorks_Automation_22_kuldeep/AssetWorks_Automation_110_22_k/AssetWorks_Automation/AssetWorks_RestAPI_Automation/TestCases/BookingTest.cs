﻿using AssetWorks_RestAPI_Automation.Config;
using AssetWorks_API_Automation.Webservices;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Booking_Automation.API_Functions;

namespace AssetWorks_API_Automation.RestGetEndPoint
{
    internal class BookingTest : GetToken
    {
       
        [TestCase("UserData.json", "TC01_ValidateUser")]
        public void ValidateToken(object[] testParameter)
        {
            var tokenObject=GenerateToken();
            Console.WriteLine(tokenObject.token);
        }
        [TestCase("Booking.json", "TC01_CreateUserBooking"), Order(1)]
        public void CreateUserBooking(object[] testParameter)
        {

            Booking objBooking = new Booking();
            Settings.Logger.Info("LoadTestData function execution started.....");
            objBooking.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            Settings.Logger.Info("Create function execution started.....");
            var content = objBooking.CreateBooking();
        }

        [TestCase("Booking.json", "GetUserBooking"), Order(2)]
        public void GetUserBooking(object[] testParameter)
        {

            Booking objBooking = new Booking();
            Settings.Logger.Info("Retrive  function execution started.....");
            var content = objBooking.GetBooking();
        }

        [TestCase("Booking.json", "TC02_UpdateUserBooking"), Order(3)]
        public void UpdateUserBooking(object[] testParameter)
        {
            Booking objBooking = new Booking();
            Settings.Logger.Info("LoadTestData function execution started.....");
            objBooking.LoadTestData(testParameter[0].ToString(), testParameter[1].ToString());
            Settings.Logger.Info("Update function execution started.....");
            var content = objBooking.UpdateBooking();
        }

        [TestCase("Booking.json", "DeleteUserBooking"), Order(4)]
        public void DeleteUserBooking(object[] testParameter)
        {
            Booking objBooking = new Booking();
            Settings.Logger.Info("Delete function execution started.....");
            objBooking.DeleteBooking();
        }
        
    }
}
