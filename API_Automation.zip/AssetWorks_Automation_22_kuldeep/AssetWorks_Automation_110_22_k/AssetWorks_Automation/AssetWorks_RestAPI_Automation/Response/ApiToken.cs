﻿using System.Text.Json.Serialization;

namespace AssetWorks_API_Automation.Webservices.Response
{
    public  class ApiToken
    {
        public string token { get; set; }
    }
  
    public class UserLoginDetails
    {
        public string username { get; set; }
        public string password { get; set; }
    }


}