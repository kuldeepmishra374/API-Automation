﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;

namespace AssetWorks_API_Automation.Utility
{
    public class EmailCode
    {
        public void sendEmail(string path, String Portal1, String Portal2, String Portal3, int totalTestCases1, int totalTestCases2, int totalTestCases3, int passTestCases1, int passTestCases2, int passTestCases3, int failedTC1, int failedTC2, int failedTC3)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add("shashi.rana@rsystems.com");
            mail.From = new MailAddress("Wencotest28@gmail.com");
            mail.Subject = "Wenco Consumer, Client and Admin portals automation results";
            // mail.Body = "Test Case Name: " + testCaseName;
            mail.Body += Environment.NewLine;

            StringBuilder htmlStreamBuilder = new StringBuilder();// read html file into a string so that we can preview html in mail.......
            htmlStreamBuilder.Append("<h2 style=" + "font-family:Verdana;>" + "Test Suite run of Wenco has been completed sucessfully.</h2>");
            htmlStreamBuilder.Append("<br>");
            htmlStreamBuilder.Append("<h3 style=" + "font-family:Verdana;>" + "Please find attachment for reports for Consumer, Client and Admin portals :<div style=" + "color:#696969;></div></h3>");

            //str.Append("<html><head></head><title></title>");
            //str.Append("<body style='font-size:12px;font-family:Trebuchet MS;'>");
            string HtmlBody = ExportDatatableToHtml(createTable(Portal1, Portal2, Portal3, totalTestCases1, totalTestCases2, totalTestCases3, passTestCases1, passTestCases2, passTestCases3, failedTC1, failedTC2, failedTC3));
            htmlStreamBuilder.Append(HtmlBody);
            mail.Body += htmlStreamBuilder;
            mail.IsBodyHtml = true;

            System.Net.Mail.Attachment attachment;

            string[] filePaths = Directory.GetFiles(path);

            // Get the files that their extension are either pdf of xls.
            var files = filePaths.Where(x => Path.GetExtension(x).Contains(".html"));

            // Loop through the files enumeration and attach each file in the mail.
            foreach (var file in files)
            {
                attachment = new Attachment(file);
                mail.Attachments.Add(attachment);
            }

            //attachment = new System.Net.Mail.Attachment(path);
            //mail.Attachments.Add(attachment);

            //SmtpClient smtp = new SmtpClient();
            //smtp.Host = "localhost";
            //smtp.Port = 25;

            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            SmtpServer.EnableSsl = true;
            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("Wencotest28", "Welcome@123");

            SmtpServer.Send(mail);
        }

        public DataTable createTable(String Portal1, String Portal2, String Portal3, int totalTestCases1, int totalTestCases2, int totalTestCases3, int passTestCases1, int passTestCases2, int passTestCases3, int failedTC1, int failedTC2, int failedTC3)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Module Name", typeof(string));
            table.Columns.Add("Total Tests", typeof(int));
            table.Columns.Add("Pass Tests", typeof(int));
            table.Columns.Add("Failed Tests", typeof(int));
            table.Rows.Add(Portal1, totalTestCases1, passTestCases1, failedTC1);
            table.Rows.Add(Portal2, totalTestCases2, passTestCases2, failedTC2);
            table.Rows.Add(Portal3, totalTestCases3, passTestCases3, failedTC3);
            return table;
        }

        protected string ExportDatatableToHtml(DataTable dt)
        {
            StringBuilder strHTMLBuilder = new StringBuilder();
            strHTMLBuilder.Append("<html >");
            strHTMLBuilder.Append("<head>");
            strHTMLBuilder.Append("</head>");
            strHTMLBuilder.Append("<body>");
            strHTMLBuilder.Append(@"<table border='4'><tr><th COLSPAN = '4' style = 'background: #14beff; color: #fff;' ><h3 style = 'padding: 6px; margin:0;'> Wenco Regression results </ h3 ></ th ></ tr > ");
            //strHTMLBuilder.Append("<table cellpadding='1' cellspacing='1' bgcolor='white' style='font-family:Garamond; font-size:large; border: 1px solid #333'>");

            strHTMLBuilder.Append("<tr >");
            foreach (DataColumn myColumn in dt.Columns)
            {
                strHTMLBuilder.Append("<td >");
                strHTMLBuilder.Append(myColumn.ColumnName);
                strHTMLBuilder.Append("</td>");
            }
            strHTMLBuilder.Append("</tr>");

            foreach (DataRow myRow in dt.Rows)
            {
                strHTMLBuilder.Append("<tr >");
                foreach (DataColumn myColumn in dt.Columns)
                {
                    strHTMLBuilder.Append("<td >");
                    strHTMLBuilder.Append(myRow[myColumn.ColumnName].ToString());
                    strHTMLBuilder.Append("</td>");
                }
                strHTMLBuilder.Append("</tr>");
            }

            //Close tags.
            strHTMLBuilder.Append("</table>");
            strHTMLBuilder.Append("</body>");
            strHTMLBuilder.Append("</html>");

            string Htmltext = strHTMLBuilder.ToString();

            return Htmltext;
        }
    }
}