﻿using System.Collections.Generic;
using System.Data.SqlClient;
//using System.Data.SqlClient;

using System.Linq;
using System;
using AssetWorks_RestAPI_Automation.Config;
using System.Data;
using Booking_Automation.Config.Database_Query;

namespace AssetWorks_API_Automation.Utility
{
    public class DBConnection
    {
        private static string Database;
        private static string User_id;
        private static string Password;
        private static string Server;
        public static string DBResponse_user_id;
        public static string DBResponse_password;
        
        /// <summary>
        /// Database connection Creation
        /// </summary>
        public static SqlConnection DataBaseConnection()
        {

            Database = Settings.DatabaseName;
            User_id = Settings.DBusername;
            Password = Settings.DBpassword;
            Server = Settings.Server;
            string connectionString = $"Server={Server}; database= {Database} ;User ID={User_id} ;Password={Password}; Trusted_Connection = True";

            SqlConnection connectionObject = new SqlConnection(connectionString);
            if (connectionObject.State == System.Data.ConnectionState.Closed)
            {
                connectionObject.Open();
            }
            return connectionObject;
        }

        /// <summary>
        /// Reading data from Sql query
        /// </summary>
        public static void SqlDataReader(string DBquery, SqlConnection connectionObject)
        {

            List<List<String>> ResultSet = new List<List<String>>();

            SqlCommand cm = new SqlCommand(DBquery, connectionObject);
            SqlDataReader dr = cm.ExecuteReader();

            while (dr.Read())
            {
                var rec = new List<string>();
                for (int i = 0; i <= dr.FieldCount - 1; i++)
                {
                    rec.Add(dr.GetString(i));
                }
                ResultSet.Add(rec);
            }
            DBResponse_user_id = ResultSet[0].First();
            DBResponse_password = ResultSet[0].Last();

            connectionObject.Close();
        }

        /// <summary>
        /// Reading data from Sql query and returning reader object
        /// </summary>
        public static List<List<String>> SqlQueryReader(string DBquery, SqlConnection connectionObject)
        {

            List<List<String>> ResultSet = new List<List<String>>();

            SqlCommand cm = new SqlCommand(DBquery, connectionObject);
            SqlDataReader dr = cm.ExecuteReader();

            while (dr.Read())
            {
                var rec = new List<string>();
                for (int i = 0; i <= dr.FieldCount - 1; i++)
                {
                    rec.Add(dr.GetString(i));
                }
                ResultSet.Add(rec);
            }
            connectionObject.Close();
            return ResultSet;
        }


        /// <summary>
        /// Genereic method for database operation
        /// </summary>
        public static void DatabaseResponse(string sqlQuery)
        {
            var connectionObject = DataBaseConnection();
            SqlDataReader(sqlQuery, connectionObject);
        }
    }
}