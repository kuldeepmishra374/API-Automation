﻿using Newtonsoft.Json;
using RestSharp;
using AssetWorks_RestAPI_Automation.Config;

namespace AssetWorks_API_Automation.Utility
{
    // public class API_Helper<T> : TestReports
    public class API_Helper<T>
    {
        public RestClient? restClient;
        public RestRequest? restRequest;


        /// <summary>
        /// Url setup will be done using this method.
        /// </summary>
        public RestClient UrlSetup(string endPoint)
        {

            Settings.Logger.Info("UrlSetup function execution started.....");
            var BaseUrl = new Uri(Settings.BaseURL + endPoint);
            Console.WriteLine(BaseUrl);
            Settings.Logger.Info($"URL details: '{BaseUrl}'");
            var restClient = new RestClient(BaseUrl);
            return restClient;
        }

        /// <summary>
        /// Delete request creation
        /// </summary>
        public RestRequest CreateDeleteRequest()
        {
            var restRequest = new RestRequest("", Method.Delete);
            restRequest.AddHeader("Accept", "application/json");
            return restRequest;
        }

        /// <summary>
        /// Delete request creation
        /// </summary>
        public RestRequest CreateDeleteRequest(dynamic token)
        {
            var restRequest = new RestRequest("", Method.Delete);
            restRequest.AddHeader("Accept", "application/json");
            //  restRequest.AddCookie("token", token);
            return restRequest;
        }

        /// <summary>
        /// Put request creation
        /// </summary>
        public RestRequest CreatePutRequest(string payloadData)
        {
            var restRequest = new RestRequest("", Method.Put);
            restRequest.AddHeader("Accept", "application/json");
            restRequest.AddParameter("application/json", payloadData, ParameterType.RequestBody);
            return restRequest;
        }

        /// <summary>
        /// Put request creation
        /// </summary>
        //public RestRequest CreatePutRequest(string payloadData, dynamic token)
        //{
        //    var restRequest = new RestRequest("", Method.Put);
        //    restRequest.AddHeader("Accept", "application/json");
        //    //  restRequest.AddParameter("application/json", payloadData, ParameterType.RequestBody);
        //    restRequest.AddJsonBody(payloadData);
        //    //  restRequest.AddCookie("token", token);
        //    return restRequest;
        //}

        // public RestRequest CreatePutRequest(string payloadData, dynamic token)
        public RestRequest CreatePutRequest(string payloadData, string token)
        {
            var restRequest = new RestRequest("", Method.Put);
            restRequest.AddHeader("Accept", "application/json");
            restRequest.AddParameter("application/json", payloadData, ParameterType.RequestBody);

            restRequest.AddHeader("Cookie", "token=" + token);
            return restRequest;
        }

        /// <summary>
        /// Post request creation
        /// </summary>
        // public RestRequest CreatePostRequest(object payloadData)
        public RestRequest CreatePostRequest(string payloadData)
        {
            var restRequest = new RestRequest("", Method.Post);
            restRequest.AddHeader("Accept", "application/json");
            restRequest.AddParameter("application/json", payloadData, ParameterType.RequestBody);
            //  restRequest.AddJsonBody(payloadData, "application/json");
            //  restRequest.AddJsonBody(payloadData);
            return restRequest;
        }

        /// <summary>
        /// Get request creation
        /// </summary>
        public RestRequest CreateGetRequest()
        {
            var restRequest = new RestRequest("", Method.Get);
            restRequest.AddHeader("Accept", "application/json");
            return restRequest;

        }

        //public RestRequest CreateGetRequest(dynamic url)
        //{
        //    var restRequest = new RestRequest(url.ToString(), Method.Get);
        //    restRequest.AddHeader("Accept", "application/json");
        //    return restRequest;

        //}

        /// <summary>
        /// Request will be executed and response will be returnes using this method
        /// </summary>
        public RestResponse GetResponse(RestClient client, RestRequest request)
        {
            // return (RestResponse)client.Execute(request);
            return client.Execute(request);
        }


        /// <summary>
        /// Response deserialization method 
        /// </summary>

        public H GetContent<H>(RestResponse response)
        {
            //  H? dataObject = new JsonSerializer().Deserialize<H>(response.Content.ToString());

            H? dataObject = JsonConvert.DeserializeObject<H>(response.Content);
            return dataObject;
        }

        /// <summary>
        /// Response serialization method 
        /// </summary>
        public string Serialize(dynamic content)
        {
            var serializeObject = JsonConvert.SerializeObject(content, Formatting.Indented);
            return serializeObject;
        }

    }
}
