﻿namespace AssetWorks_API_Automation.API
{

    internal static class ApiUrl
    {
       

        public static string getuser_Endpoint = "/api/users/2";
        public static string postuser_Endpoint = "/api/users";
        public static string putuser_Endpoint = "/api/users/2";
        public static string deleteuser_Endpoint = "/api/users/2";

        public static string updateuserBooking = "/booking/2362";
        public static string createuserBooking = "/booking";
        public static string getuserBooking = "/booking/2362";
        public static string deleteuserBooking = "/booking/2362";

        public static string tokenUrl = "/auth";



        public static long ToUnixTimeStamp(this System.DateTime date)
        {
            var dateTimeOffset = new System.DateTimeOffset(date);
            return dateTimeOffset.ToUnixTimeSeconds();
        }


        public static string[] validationValuesAlerts = new string[]
                {
                "Invalid username or password",
                "AlertEntity with id $ does not exist.",
                "Sequence contains no elements"
                };
    }
}