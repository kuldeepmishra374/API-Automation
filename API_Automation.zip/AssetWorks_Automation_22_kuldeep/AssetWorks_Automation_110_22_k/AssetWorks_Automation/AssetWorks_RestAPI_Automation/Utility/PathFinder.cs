﻿using System;
using System.IO;
using System.Reflection;

namespace AssetWorks_API_Automation.Utility
{
    public class PathFinder
    {
        public static string GetWencoFilePath(string fileType)
        {
            string path;
            Assembly assembly = Assembly.GetExecutingAssembly();

            if (fileType.Equals("Object"))
            {
                path = Path.Combine(Path.GetDirectoryName(assembly.Location), "Objects.xlsx");
            }
            else
            {
                path = Path.Combine(Path.GetDirectoryName(assembly.Location), "QA_TestData.xlsx");
                //string path = Path.Combine(Path.GetDirectoryName(assembly.Location), "Staging_TestData.xlsx");
            }
            return path;
        }

        public static string GetWencoDataUploadFilePath(String sheetName)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string path = Path.Combine(Path.GetDirectoryName(assembly.Location), "TestData\\" + sheetName);
            string[] filePath = path.Split(new[] { "\\bin\\Debug" }, StringSplitOptions.None);
            return filePath[0] + filePath[1];
        }

        public static string SheetName
        {
            get { return ConfigReader.GetConfigKey("SheetName"); }
        }

        public static string FileName
        {
            get { return ConfigReader.GetConfigKey("FileName"); }
        }
    }
}