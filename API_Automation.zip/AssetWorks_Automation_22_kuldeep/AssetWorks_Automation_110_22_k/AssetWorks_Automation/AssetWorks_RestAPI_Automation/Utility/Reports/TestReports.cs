﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework.Interfaces;
using AssetWorks_RestAPI_Automation.Config;
using AventStack.ExtentReports.Reporter.Config;

namespace AssetWorks_API_Automation.Reports
{
    public class TestReports
    {
        protected static ExtentReports _extent;
        protected static ExtentTest _test;

        /// <summary>
        /// Set Up the extent report.
        /// </summary>
        public static void SetupExtentReport()
        {
            if (Settings.ExtentReport)
            {
                try
                {
                    //To create report directory and add HTML report into it
                    if(_extent == null)
                        _extent = new ExtentReports();                  
                    string? solutionPath=null;
                    string parentSolutionPath;
                    string? folderName = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                    if (folderName != null)
                    {
                        solutionPath = folderName.Substring(0, folderName.LastIndexOf("\\bin"));
                    }
                    parentSolutionPath = Path.Combine(folderName.Substring(0, folderName.LastIndexOf("\\bin")), "Test_Execution_Reports" + "\\");
                    if (!Directory.Exists(parentSolutionPath))
                        Directory.CreateDirectory(parentSolutionPath);
                    
                    ExtentSparkReporter spark = new ExtentSparkReporter(parentSolutionPath + "\\Automation_Report" + ".html");
                    spark.Config.Theme = Theme.Standard;                    
                    spark.Config.DocumentTitle = "ExtentReport";
                    spark.Config.ReportName = "AssetWorksReport";                   
                    _extent.AttachReporter(spark);
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        /// <summary>
        /// create test in extent report
        /// </summary>
        public static void CreateTest()
        {

            TestContext.TestAdapter _currentTest = TestContext.CurrentContext.Test;
            try
            {
                _test = _extent.CreateTest(_currentTest.Name);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Store the results in extent report
        /// </summary>
        public static void StorerResults()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stacktrace = "" + TestContext.CurrentContext.Result.StackTrace + "";
            var errorMessage = TestContext.CurrentContext.Result.Message;
            Status logstatus;
            switch (status)
            {
                case TestStatus.Failed:
                    logstatus = Status.Fail;
                    // string screenShotPath = Capture(driver, TestContext.CurrentContext.Test.Name);
                    _test.Log(logstatus, "Test ended with " + logstatus + " - " + errorMessage);
                    // _test.Log(logstatus, "Snapshot below: " + _test.AddScreenCaptureFromPath(screenShotPath));
                    break;
                case TestStatus.Skipped:
                    logstatus = Status.Skip;
                    _test.Log(logstatus, "Test ended with " + logstatus);
                    break;
                default:
                    logstatus = Status.Pass;
                    _test.Log(logstatus, "Test ended with " + logstatus);
                    break;
            }
        }

        /// <summary>
        /// Flush the extent report
        /// </summary>
        public static void FlushExtentReport()
        {
            if (Settings.ExtentReport)
                _extent.Flush();
        }
    }
}