﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
//using RestSharp.Serialization.Json;
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using AssetWorks_API_Automation.API;
using AssetWorks_API_Automation.Utility;
using AssetWorks_API_Automation.Webservices.Response;
using AssetWorks_API_Automation.Webservices.Request;
using AssetWorks_RestAPI_Automation.Config;
using NUnit.Framework;
using RestSharp.Serializers;
using Booking_Automation.Request;
using Booking_Automation.Config.Database_Query;

namespace AssetWorks_API_Automation.Webservices
{

    internal class GetToken : ConfigReader
    {
        public static string token = string.Empty;
        public static Object testcasePayload;

        /// <summary>
        /// Username and password will be loaded from database
        /// </summary>
        public void LoadingUsernamePassword()
        {
            DBConnection.DatabaseResponse(DBQuery.CredentialforToken);
            var apihelperObject = new API_Helper<UserLoginDetails>();
            UserLoginDetails userLoginDetails = new UserLoginDetails();
            Console.WriteLine("!..Hi... We are Generating token after taking data from database...!");
            // Taking username password from setting.cs for token generation 
            //userLoginDetails.username = Settings.userName;
            // userLoginDetails.password = Settings.passWord;

            userLoginDetails.username = DBConnection.DBResponse_user_id;
            userLoginDetails.password = DBConnection.DBResponse_password;
            testcasePayload = apihelperObject.Serialize(userLoginDetails);
        }

        /// <summary>
        /// Preparing token request with Json data 
        /// </summary>
        public RestRequest CreateUserTokenRequest()
        {

            // var request = new RestRequest(Method.Post);
            // var Client = new RestClient(Settings.BaseURL + ApiUrl.tokenUrl);
            //  var client = new HttpClient()
            //(Settings.BaseURL + ApiUrl.tokenUrl);
            var request = new RestRequest("", Method.Post);
            // var req = new RestRequest(client, Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", testcasePayload, ParameterType.RequestBody);
            return request;
        }


        /// <summary>
        /// Executing request and returning response back 
        /// </summary>
        //public IRestResponse GetTokenResponse(RestRequest request)
        //{
        //    // var Client = new RestClient(ConfigReader.GetConfigKey("ApiUrl") + ApiUrl.tokenUrl);
        //    var Client = new RestClient(Settings.BaseURL + ApiUrl.tokenUrl);
        //    IRestResponse response = Client.Execute(request);
        //    //return an AccessToken
        //    return response;
        //}

        public RestResponse GetTokenResponse(RestRequest request)
        {
            // var Client = new RestClient(ConfigReader.GetConfigKey("ApiUrl") + ApiUrl.tokenUrl);
            var Client = new RestClient(Settings.BaseURL + ApiUrl.tokenUrl);
            RestResponse response = Client.Execute(request);
            //return an AccessToken
            return response;
        }

        /// <summary>
        /// Parent method for token generation
        /// </summary>
        public ApiToken GenerateToken()
        {
            LoadingUsernamePassword();
            RestResponse reponseToken = ((RestResponse)GetTokenResponse(CreateUserTokenRequest()));
            var apihelperObject = new API_Helper<ApiToken>();
            ApiToken apiToken = apihelperObject.GetContent<ApiToken>(reponseToken);
            token = apiToken.token;
            return apiToken;
        }

    }
}