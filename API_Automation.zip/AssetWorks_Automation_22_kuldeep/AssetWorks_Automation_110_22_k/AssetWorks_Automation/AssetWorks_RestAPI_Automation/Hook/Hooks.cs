﻿using AssetWorks_API_Automation.Reports;
using AssetWorks_RestAPI_Automation.Config;
using AssetWorks_RestAPI_Automation.ConfigData;

namespace AssetWorks_RestAPI_Automation.Hook
{
    /// <summary>
    /// Hooks class for all One time setup and tear down to implement test preconditions
    /// </summary>
    [TestFixture]
    public class Hooks
    {
        /// <summary>
        /// Initializing all config variables
        /// </summary>
        [OneTimeSetUp]
        public void BeforeRun()
        {
            ConfigurationData.SetConfigData();
            Settings.Logger.Info("------------------Initilizing Test Execution---------------");
            TestReports.SetupExtentReport();        
        }          

       /// <summary>
        /// Creating instance of browser and login into application
        /// </summary>
        [SetUp]
        public void Setup()
        {
            var testName = TestContext.CurrentContext.Test.Name;
            var testDesc = TestContext.CurrentContext.Test.Properties.Get("Description");
            Settings.Logger.Info($"------------Starting executing test '{testName}' having Description as '{testDesc}' -------------------");
            TestReports.CreateTest();           

        }


        /// <summary>
        /// Closing browser after completing test execution
        /// </summary>
        [TearDown]
        public void AfterTestRUn()
        {           

            Settings.Logger.Info($"------------Finishing executing test '{TestContext.CurrentContext.Test.Name}' having Description as '{TestContext.CurrentContext.Test.Properties.Get("Description")}' -------------------");
            TestReports.StorerResults();
        }


        /// <summary>
        /// Genrating extent report after completing the test execution
        /// </summary>
        [OneTimeTearDown]
        public void AfterRun()
        {

            Settings.Logger.Info("------------------Finishing Test Execution---------------");
            TestReports.FlushExtentReport();
        }
    }
}