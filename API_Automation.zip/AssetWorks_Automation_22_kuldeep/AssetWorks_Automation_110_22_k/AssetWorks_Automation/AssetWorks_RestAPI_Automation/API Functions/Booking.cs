﻿using AssetWorks_RestAPI_Automation.Config;
using AssetWorks_API_Automation.API;
using AssetWorks_API_Automation.Utility;
using AssetWorks_API_Automation.Webservices;
using Booking_Automation.Request;
using RestSharp;

namespace Booking_Automation.API_Functions
{
    public class Booking : ConfigReader
    {
        public static Object? testcasePayload;
        public string? statusCode;
        public static dynamic? inputData;

        /// <summary>
        /// Load Testdata 
        /// </summary>
        public void LoadTestData(string fileName, string testcaseName)
        {
            testcasePayload = LoadTestDataFromJson(fileName, testcaseName);
        }

        /// <summary>
        /// Reusable method for Get request 
        /// </summary>
        public GetBooking GetBooking()
        {
            var apihelperObject = new API_Helper<GetBooking>();
            Settings.Logger.Info($"Currently used Get Endpoints : {ApiUrl.getuserBooking} ");
            var url = apihelperObject.UrlSetup(ApiUrl.getuserBooking);
            // var request = apihelperObject.CreateGetRequest(url);
            var request = apihelperObject.CreateGetRequest();
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<GetBooking>(response);
            Settings.Logger.Info($"First Name : {content.Firstname} ");
            Settings.Logger.Info($"Last Name : {content.Lastname} ");
            Settings.Logger.Info($"Additional needs : {content.Additionalneeds} ");
            return content;
        }

        //public GetBooking GetBooking()
        //{
        //    var apihelperObject = new API_Helper<UserPageResponse>();
        //    // GetToken getToken = new GetToken();
        //    var client = new RestClientOptions();
        //    Settings.Logger.Info($"Currently used Get Endpoints : {ApiUrl.getuserBooking} ");
        //    client.BaseUrl = new Uri(Settings.BaseURL + ApiUrl.getuserBooking);
        //    var request = new RestRequest(client.BaseUrl, Method.Get);
        //    request.AddHeader("Accept", "application/json");
        //    var clp = new RestClient(client.BaseUrl);

        //    var response = apihelperObject.GetResponse(clp, request);

        //    var content = apihelperObject.GetContent<GetBooking>(response);
        //    Settings.Logger.Info($"First Name : {content.Firstname} ");
        //    Settings.Logger.Info($"Last Name : {content.Lastname} ");
        //    Settings.Logger.Info($"Additional needs : {content.Additionalneeds} ");
        //    return content;
        //}

        /// <summary>
        /// Reusable method for Post request 
        /// </summary>
        public CreateBooking CreateBooking()
        {
            var apihelperObject = new API_Helper<CreateBooking>();
            var url = apihelperObject.UrlSetup(ApiUrl.createuserBooking);
            // var request = apihelperObject.CreatePostRequest(testcasePayload);
            var request = apihelperObject.CreatePostRequest(testcasePayload.ToString());
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<CreateBooking>(response);

            ApiUrl.getuserBooking = $"/booking/{content.Bookingid}";
            ApiUrl.updateuserBooking = $"/booking/{content.Bookingid}";
            ApiUrl.deleteuserBooking = $"/booking/{content.Bookingid}";
            Settings.Logger.Info($"Generated Booking ID :{content.Bookingid} ");
            Settings.Logger.Info($"Preparing Get Endpoints after id getting generated :{ApiUrl.getuserBooking} ");
            Settings.Logger.Info($"Preparing Put Endpoints after id getting generated :{ApiUrl.updateuserBooking} ");
            return content;
        }


        /// <summary>
        /// Reusable method for Put request 
        /// </summary>
        public UpdateBooking UpdateBooking()
        {
            var apihelperObject = new API_Helper<UpdateBooking>();
            var url = apihelperObject.UrlSetup(ApiUrl.updateuserBooking);
            GetToken getToken = new GetToken();
            getToken.GenerateToken();
            Settings.Logger.Info($"Generated Token :{GetToken.token} ");
            var request = apihelperObject.CreatePutRequest(testcasePayload.ToString(), GetToken.token);
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<UpdateBooking>(response);
            Settings.Logger.Info($"First Name : {content.Firstname} ");
            Settings.Logger.Info($"Last Name : {content.Lastname} ");
            Settings.Logger.Info($"Additional needs : {content.Additionalneeds} ");

            return content;
        }


        /// <summary>
        /// Reusable method for Delete request 
        /// </summary>
        public void DeleteBooking()
        {
            var apihelperObject = new API_Helper<dynamic>();
            var url = apihelperObject.UrlSetup(ApiUrl.deleteuserBooking);
            GetToken getToken = new GetToken();
            getToken.GenerateToken();
            var request = apihelperObject.CreateDeleteRequest(GetToken.token);
            Settings.Logger.Info($"Generated Token : {GetToken.token} ");
            var response = apihelperObject.GetResponse(url, request);
            string[] Booking_Id = ApiUrl.deleteuserBooking.Split('/');
            Settings.Logger.Info($"Deleted Booking ID : {Booking_Id[2]} ");
            Settings.Logger.Info($"Status of Delete Request :{response.StatusCode} ");
        }
    }
}
