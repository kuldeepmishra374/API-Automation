﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks_API_Automation.Utility;
using AssetWorks_API_Automation.Webservices.Request;
using AssetWorks_API_Automation.API;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
//using RestSharp.Serialization.Json;
using AssetWorks_RestAPI_Automation.Config;

namespace AssetWorks_API_Automation.Webservices.API_Functions
{
    public class UsrerInterface : ConfigReader
    {
        public static Object testcasePayload;
        //  public static SoftAssertions softAssertion;
        public string statusCode;
        public static dynamic inputData;
        public UsrerInterface()
        {
            //softAssertion = new SoftAssertions();
        }

        /// <summary>
        /// Load Testdata 
        /// </summary>
        public void LoadTestData(string fileName, string testcaseName)
        {
            Settings.Logger.Info("Loading .json file test data started.....");
            testcasePayload = LoadTestDataFromJson(fileName, testcaseName);
            Settings.Logger.Info($"Loading .json file test data completed:  '{testcasePayload}'");
        }

        /// <summary>
        /// Reusable method for Get request 
        /// </summary>
        public UserPageResponse GetUser()
        {
            var apihelperObject = new API_Helper<UserPageResponse>();
            var url = apihelperObject.UrlSetup(ApiUrl.getuser_Endpoint);
            var request = apihelperObject.CreateGetRequest();
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<UserPageResponse>(response);

            inputData = JObject.Parse(testcasePayload.ToString());
            return content;
        }

        /// <summary>
        /// Reusable method for Post request 
        /// </summary>
        public PostRequest CreateUser()
        {
            var apihelperObject = new API_Helper<PostRequest>();
            var url = apihelperObject.UrlSetup(ApiUrl.postuser_Endpoint);
            var request = apihelperObject.CreatePostRequest(testcasePayload.ToString());
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<PostRequest>(response);
            inputData = JObject.Parse(testcasePayload.ToString());
            return content;
        }

        //public PostRequest CreateUser()
        //{
        //    var apihelperObject = new API_Helper<PostRequest>();
        //    //  var url = apihelperObject.UrlSetup(ApiUrl.postuser_Endpoint);
        //    var client = new RestClientOptions();
        //    client.BaseUrl = new Uri(Settings.BaseURL + ApiUrl.postuser_Endpoint);
        //    var clp = new RestClient(client.BaseUrl);
        //    var request = apihelperObject.CreatePostRequest(testcasePayload.ToString());
        //    //   var request = apihelperObject.CreatePostRequest(testcasePayload);
        //    //  var response = apihelperObject.GetResponse(url, request);

        //    ////  var apihelperObject = new API_Helper<UserPageResponse>();
        //    //  // GetToken getToken = new GetToken();
        //    //  var client = new RestClientOptions();
        //    //  client.BaseUrl = new Uri(Settings.BaseURL + ApiUrl.postuser_Endpoint);
        //    //  var request = new RestRequest(client.BaseUrl, Method.Get);
        //    //  request.AddHeader("Accept", "application/json");
        //    //  var clp = new RestClient(client.BaseUrl);
        //    //  // var url = apihelperObject.UrlSetup(ApiUrl.getuser_Endpoint);
        //    //  //log4net.info()
        //    //  var request = apihelperObject.CreateGetRequest(url);
        //    var response = apihelperObject.GetResponse(clp, request);

        //    var content = apihelperObject.GetContent<PostRequest>(response);
        //    inputData = JObject.Parse(testcasePayload.ToString());
        //    return content;
        //}

        /// <summary>
        /// Reusable method for Put request 
        /// </summary>
        public UserPutRequest UpdateUser()
        {
            var apihelperObject = new API_Helper<UserPutRequest>();
            var url = apihelperObject.UrlSetup(ApiUrl.putuser_Endpoint);
            var request = apihelperObject.CreatePutRequest(testcasePayload.ToString());
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<UserPutRequest>(response);
            return content;
        }

        /// <summary>
        /// Reusable method for Delete request 
        /// </summary>
        public dynamic DeleteUser()
        {
            var user = new API_Helper<dynamic>();
            var url = user.UrlSetup(ApiUrl.deleteuser_Endpoint);
            var request = user.CreateDeleteRequest();
            var response = user.GetResponse(url, request);
            return response;
        }


        /// <summary>
        /// Reusable method for Post request with Serialization of data
        /// </summary>
        public CreateUser Post_Request(dynamic payloadData)
        {
            var apihelperObject = new API_Helper<CreateUser>();
            var url = apihelperObject.UrlSetup(ApiUrl.postuser_Endpoint);
            var jsonRequest = apihelperObject.Serialize(payloadData);
            var request = apihelperObject.CreatePostRequest(jsonRequest);
            var response = apihelperObject.GetResponse(url, request);
            var content = apihelperObject.GetContent<CreateUser>(response);
            return content;
        }


        /// <summary>
        /// Validation of Get request
        /// </summary>
        public void VerifyGetRequest(UserPageResponse userpageResponse)
        {
            Assert.Multiple(() =>
            {
                // Assert.That(userpageResponse.data[0].id, Is.EqualTo(Convert.ToInt32(inputData.id)));
                //  Assert.AreEqual(Convert.ToInt32(inputData.id), userpageResponse.data[0].id);
                Assert.That(userpageResponse.data.id, Is.EqualTo(Convert.ToInt32(inputData.id)));
                Settings.Logger.Info($"Expected data : {Convert.ToInt32(inputData.id)}, actual data is :{userpageResponse.data.id} ");

                Assert.That(userpageResponse.data.first_name, Is.EqualTo(Convert.ToString(inputData.first_name)));
                Settings.Logger.Info($"Expected data : {inputData.first_name}, actual data is :{userpageResponse.data.first_name} ");

                Assert.That(userpageResponse.data.last_name, Is.EqualTo(Convert.ToString(inputData.last_name)));
                Settings.Logger.Info($"Expected data : {inputData.last_name}, actual data is :{userpageResponse.data.last_name} ");

                Assert.That(userpageResponse.data.email, Is.EqualTo(Convert.ToString(inputData.email)));
                Settings.Logger.Info($"Expected data : {inputData.email}, actual data is :{userpageResponse.data.email} ");

            });
        }

        public void VerifyWithGetInvalidUserRequest(UserPageResponse userpageResponse)
        {
            Assert.Multiple(() =>
            {
                Assert.That(userpageResponse.data.id, Is.Not.EqualTo(Convert.ToInt32(inputData.id)));
                Settings.Logger.Info($"Expected data : {Convert.ToInt32(inputData.id)}, actual data is :{userpageResponse.data.id} ");

                Assert.That(userpageResponse.data.first_name, Is.Not.EqualTo(Convert.ToString(inputData.first_name)));
                Settings.Logger.Info($"Expected data : {inputData.first_name}, actual data is :{userpageResponse.data.first_name} ");

                Assert.That(userpageResponse.data.last_name, Is.Not.EqualTo(Convert.ToString(inputData.last_name)));
                Settings.Logger.Info($"Expected data : {inputData.last_name}, actual data is :{userpageResponse.data.last_name} ");

                Assert.That(userpageResponse.data.email, Is.Not.EqualTo(Convert.ToString(inputData.email)));
                Settings.Logger.Info($"Expected data : {inputData.email}, actual data is :{userpageResponse.data.email} ");
            });
        }

        /// <summary>
        /// Validation of Put request
        /// </summary>
        public void VerifyPutRequest(dynamic serverResponse, string fileName, string testcaseName)
        {
            var testcasePayload = LoadTestDataFromJson(fileName, testcaseName);
            Console.WriteLine(testcasePayload);
            inputData = JObject.Parse(testcasePayload.ToString());
            Assert.Multiple(() =>
            {
                Assert.That(serverResponse.Name, Is.EqualTo(Convert.ToString(inputData.name)));
                Settings.Logger.Info($"Expected data : {inputData.name}, actual data is :{serverResponse.Name} ");

                Assert.That(serverResponse.Job, Is.EqualTo(Convert.ToString(inputData.job)));
                Settings.Logger.Info($"Expected data : {inputData.job}, actual data is :{serverResponse.Job} ");
            });
        }


        /// <summary>
        /// Validation of Post request
        /// </summary>
        public void VerifyPostRequest(dynamic serverResponse)
        {
            Assert.Multiple(() =>
            {
                //Assert.AreEqual(Convert.ToString(inputData.name), serverResponse.Name);
                Assert.That(serverResponse.Name, Is.EqualTo(Convert.ToString(inputData.name)));

                Assert.That(serverResponse.Job, Is.EqualTo(Convert.ToString(inputData.job)));
            });

        }

        /// <summary>
        /// Validation of Delete request
        /// </summary>
        public void VerifyDeleteRequest(dynamic serverResponse)
        {
            //softAssertion.Add(Convert.ToString("204"), serverResponse.Statuscode, "Created User Name");
            //softAssertion.AssertAll();
            //Assert.AreEqual(Convert.ToString("204"), serverResponse.Statuscode);

        }

        [TearDown]
        public void TearDownMethod()
        {
            testcasePayload = null;
            inputData = null;

        }
    }
}
